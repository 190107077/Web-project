function myFunction(x) {
  x.style.color("red");
}